package inkball;

import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class App extends PApplet {

    // All the entities
    private List<Ball> balls;
    private List<Wall> walls;
    private List<Hole> holes;
    private List<Spawner> spawners;
    private List<PlayerLine> playerLines;
    private List<Tile> tiles;

    private Player player;
    private Level level;
    private Config config;

    // Variables for game logic and state
    private int score;
    private float spawnTimer;
    private float levelTimer;
    private boolean isPaused;
    private boolean isGameOver;
    private boolean isLevelWon;
    private boolean isLevelLost;
    private int currentLevel;
    private int currentBallIndex;
    private Map<String, PImage> images;

    // Constants
    public static final int TILE_SIZE = 32;
    private static final int WINDOW_WIDTH = 576;
    private static final int WINDOW_HEIGHT = 640;
    private static final int BALL_RADIUS = 16;
    private static final int FPS = 60;

    public void settings() {
        size(WINDOW_WIDTH, WINDOW_HEIGHT);
    }

    public void setup() {
        frameRate(FPS);
        smooth(8);
        background(0);
        config = new Config("config.json");
        currentLevel = 1;
        initGame();
    }

    public void draw() {
        if (isPaused) {
            return;
        }

        if (isGameOver) {
            drawGameOverScreen();
            return;
        }

        if (isLevelWon) {
            drawLevelWonScreen();
            return;
        }

        if (isLevelLost) {
            drawLevelLostScreen();
            return;
        }

        background(0);
        updateEntities();
        drawEntities();
        drawScoreAndTimer();
        drawUnspawnedBalls();
    }

    private void initGame() {
        score = 0;
        level = new Level(currentLevel, config, this);
        spawnTimer = level.getSpawnInterval() * FPS;
        levelTimer = level.getLevelTime() * FPS;
        balls = level.getBalls();
        walls = level.getWalls();
        holes = level.getHoles();
        spawners = level.getSpawners();
        playerLines = new ArrayList<>();
        tiles = level.getTiles();
        images = new HashMap<>();
        isPaused = false;
        isGameOver = false;
        isLevelWon = false;
        isLevelLost = false;
        player = new Player(this);
        loadImages();
    }

    private void updateEntities() {
        updateBalls();
        updateLevelTimer();
        updateSpawnTimer();
        updateHoles();
        updatePlayerLines();
        updatePlayer();
    }

    private void drawEntities() {
        drawWalls();
        drawHoles();
        drawPlayerLines();
        drawBalls();
    }

    private void drawScoreAndTimer() {
        fill(255);
        textSize(16);
        textAlign(LEFT);
        text("Score: " + score, 10, 20);
        textAlign(RIGHT);
        text("Time: " + Math.round(levelTimer / FPS), width - 10, 20);
    }

    private void drawUnspawnedBalls() {
        if (!balls.isEmpty()) {
            int x = 10;
            int y = 40;
            for (int i = 0; i < Math.min(5, balls.size()); i++) {
                Ball ball = balls.get(i);
                image(images.get("ball" + ball.getColor()), x, y, TILE_SIZE, TILE_SIZE);
                x += TILE_SIZE + 10;
            }
        }
    }

    private void loadImages() {
        images.put("ball0", loadImage("inkball/ball0.png"));
        images.put("ball1", loadImage("inkball/ball1.png"));
        images.put("ball2", loadImage("inkball/ball2.png"));
        images.put("ball3", loadImage("inkball/ball3.png"));
        images.put("ball4", loadImage("inkball/ball4.png"));
        images.put("wall0", loadImage("inkball/wall0.png"));
        images.put("wall1", loadImage("inkball/wall1.png"));
        images.put("wall2", loadImage("inkball/wall2.png"));
        images.put("wall3", loadImage("inkball/wall3.png"));
        images.put("wall4", loadImage("inkball/wall4.png"));
        images.put("hole0", loadImage("inkball/hole0.png"));
        images.put("hole1", loadImage("inkball/hole1.png"));
        images.put("hole2", loadImage("inkball/hole2.png"));
        images.put("hole3", loadImage("inkball/hole3.png"));
        images.put("hole4", loadImage("inkball/hole4.png"));

        images.put("inkball_spritesheet", loadImage("inkball/inkball_spritesheet.png"));
        images.put("entrypoint", loadImage("inkball/entrypoint.png"));
    }

    public void mousePressed() {
        if (mouseButton == LEFT) {
            player.startLine(mouseX, mouseY);
        } else if (mouseButton == RIGHT) {
            player.removeLine(mouseX, mouseY);
        }
    }

    public void mouseDragged() {
        if (mouseButton == LEFT) {
            player.extendLine(mouseX, mouseY);
        }
    }

    public void mouseReleased() {
        if (mouseButton == LEFT) {
            player.endLine();
        }
    }

    public void keyPressed() {
        if (key == 'r') {
            if (isGameOver) {
                currentLevel = 1;
                initGame();
            } else {
                restartLevel();
            }
        } else if (key == ' ') {
            isPaused = !isPaused;
        }
    }

    private void updateBalls() {
        for (Ball ball : balls) {
            if (ball.isCaptured()) {
                continue;
            }
            ball.update();
            handleBallCollisions(ball);
            handleBallHoleInteraction(ball);
        }
    }

    private void updateLevelTimer() {
        if (levelTimer > 0) {
            levelTimer -= 1 / FPS;
            if (levelTimer <= 0) {
                isLevelLost = true;
            }
        }
    }

    private void updateSpawnTimer() {
        if (spawnTimer > 0) {
            spawnTimer -= 1 / FPS;
        } else {
            spawnBall();
        }
    }

    private void updateHoles() {
        for (Hole hole : holes) {
            hole.update();
        }
    }

    private void updatePlayerLines() {
        for (PlayerLine playerLine : playerLines) {
            playerLine.update();
        }
    }

    private void updatePlayer() {
        player.update();
    }

    private void handleBallCollisions(Ball ball) {
        for (Wall wall : walls) {
            if (wall.isCollidingWith(ball)) {
                ball.reflect(wall.getNormal(ball)); // Pass the 'ball' to getNormal()
                if (wall.getColor() != 0) {
                    ball.changeColor(wall.getColor());
                }
                break; // Only collide with one wall at a time
            }
        }

        for (PlayerLine playerLine : playerLines) {
            if (playerLine.isCollidingWith(ball)) {
                ball.reflect(playerLine.getNormal());
                playerLine.remove();
                break; // Only collide with one line at a time
            }
        }
    }

    private void handleBallHoleInteraction(Ball ball) {
        for (Hole hole : holes) {
            if (hole.isAttractingBall(ball)) {
                hole.attractBall(ball);
                if (hole.isBallCaptured(ball)) {
                    handleBallCapture(ball, hole);
                    break;
                }
            }
        }
    }

    private void handleBallCapture(Ball ball, Hole hole) {
        if (hole.isMatchingColor(ball) || hole.getColor() == 0 || ball.getColor() == 0) {
            ball.capture();
            score += hole.getScoreValue() * config.getScoreIncreaseFromHoleCaptureModifier();
            if (balls.size() == 1) {
                isLevelWon = true;
            }
        } else {
            ball.reset();
            score -= hole.getScoreValue() * config.getScoreDecreaseFromWrongHoleModifier();
        }
    }

    private void spawnBall() {
        if (balls.isEmpty()) {
            return;
        }
        currentBallIndex = (currentBallIndex + 1) % balls.size();
        Ball ball = balls.get(currentBallIndex);
        ball.spawn(randomSpawner());
        spawnTimer = level.getSpawnInterval() * FPS;
    }

    private Spawner randomSpawner() {
        int randomIndex = (int) (Math.random() * spawners.size());
        return spawners.get(randomIndex);
    }

    private void drawWalls() {
        for (Wall wall : walls) {
            image(images.get("wall" + wall.getColor()), wall.getX(), wall.getY(), TILE_SIZE, TILE_SIZE);
        }
    }

    private void drawHoles() {
        for (Hole hole : holes) {
            image(images.get("hole" + hole.getColor()), hole.getX(), hole.getY(), TILE_SIZE * 2, TILE_SIZE * 2);
        }
    }

    private void drawPlayerLines() {
        for (PlayerLine playerLine : playerLines) {
            playerLine.draw();
        }
    }

    private void drawBalls() {
        for (Ball ball : balls) {
            if (ball.isCaptured()) {
                continue;
            }
            image(images.get("ball" + ball.getColor()), ball.getX(), ball.getY(), ball.getWidth(), ball.getHeight());
        }
    }

    private void restartLevel() {
        initGame();
        isLevelWon = false;
        isLevelLost = false;
    }

    private void drawGameOverScreen() {
        background(0);
        fill(255);
        textSize(32);
        textAlign(CENTER);
        text("=== GAME OVER ===", width / 2, height / 2 - 30);
        textSize(24);
        text("Press 'r' to restart", width / 2, height / 2 + 30);
    }

    private void drawLevelWonScreen() {
        background(0);
        fill(255);
        textSize(32);
        textAlign(CENTER);
        text("=== LEVEL " + currentLevel + " WON! ===", width / 2, height / 2 - 30);
        textSize(24);
        text("Press 'r' to continue", width / 2, height / 2 + 30);
        if (currentLevel < level.getMaxLevels()) {
            currentLevel++;
            initGame();
        } else {
            isGameOver = true;
        }
    }

    private void drawLevelLostScreen() {
        background(0);
        fill(255);
        textSize(32);
        textAlign(CENTER);
        text("=== TIME'S UP! ===", width / 2, height / 2 - 30);
        textSize(24);
        text("Press 'r' to restart", width / 2, height / 2 + 30);
    }

    // Getter method to access playerLines
    public List<PlayerLine> getPlayerLines() {
        return this.playerLines;
    }


    public int getBallRadius() {
        return BALL_RADIUS;
    }

    public static void main(String[] args) {
        PApplet.main(new String[] { "inkball.App" });
    }
}
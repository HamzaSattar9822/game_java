package inkball;

import processing.core.PApplet;

public class Ball {
    private float x;
    private float y;
    private float dx;
    private float dy;
    private int color;
    private float width;
    private float height;
    private boolean isCaptured;

    private App app;

    public Ball(App app, int color) {
        this.app = app;
        this.color = color;
        this.width = App.TILE_SIZE;
        this.height = App.TILE_SIZE;
        this.isCaptured = false;
    }

    public void spawn(Spawner spawner) {
        this.x = spawner.getX() + App.TILE_SIZE / 2f;
        this.y = spawner.getY() + App.TILE_SIZE / 2f;
        this.dx = (int) (Math.random() * 2) * 2 - 2;
        this.dy = (int) (Math.random() * 2) * 2 - 2;
        this.isCaptured = false;
        this.width = App.TILE_SIZE;
        this.height = App.TILE_SIZE;
    }

    public void update() {
        if (!isCaptured) {
            this.x += this.dx;
            this.y += this.dy;
        }
    }

    public void reflect(float[] normal) {
        float dotProduct = this.dx * normal[0] + this.dy * normal[1];
        this.dx = this.dx - 2 * dotProduct * normal[0];
        this.dy = this.dy - 2 * dotProduct * normal[1];
    }

    public void changeColor(int color) {
        this.color = color;
    }

    public void capture() {
        this.isCaptured = true;
        this.dx = 0;
        this.dy = 0;
        this.width = 0;
        this.height = 0;
    }

    public void reset() {
        this.isCaptured = false;
        this.width = App.TILE_SIZE;
        this.height = App.TILE_SIZE;
        this.dx = 0;
        this.dy = 0;
    }

    public boolean isCaptured() {
        return this.isCaptured;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public int getColor() {
        return this.color;
    }

    public float getWidth() {
        return this.width;
    }

    public float getHeight() {
        return this.height;
    }

    public void setDx(float dx) {
        this.dx = dx;
    }

    public void setDy(float dy) {
        this.dy = dy;
    }

    public float getDx() {
        return dx;
    }

    public float getDy() {
        return dy;
    }
}
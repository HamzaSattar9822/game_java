package inkball;

public class Spawner {
    private float x;
    private float y;

    public Spawner(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return this.x * App.TILE_SIZE;
    }

    public float getY() {
        return this.y * App.TILE_SIZE;
    }
}
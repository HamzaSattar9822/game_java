package inkball;

import processing.core.PApplet;
import processing.data.StringList;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Level {
    private int levelNumber;
    private Config config;
    private StringList levelLayout;
    private List<Ball> balls;
    private List<Wall> walls;
    private List<Hole> holes;
    private List<Spawner> spawners;
    private List<Tile> tiles;
    private int maxLevels;
    private App app;

    public Level(int levelNumber, Config config, App app) {
        this.app = app;
        this.levelNumber = levelNumber;
        this.config = config;
        this.levelLayout = loadLevelLayout();
        this.balls = new ArrayList<>();
        this.walls = new ArrayList<>();
        this.holes = new ArrayList<>();
        this.spawners = new ArrayList<>();
        this.tiles = new ArrayList<>();
        this.maxLevels = config.getMaxLevels();
        parseLevelLayout();
    }

    private StringList loadLevelLayout() {
        String filePath = this.config.getLayout(this.levelNumber);
        StringList lines = new StringList();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error loading level layout from: " + filePath);
        }
        return lines;
    }

    private void parseLevelLayout() {
        int row = 0;
        int col = 0;
        for (String line : this.levelLayout) {
            for (int i = 0; i < line.length(); i++) {
                char character = line.charAt(i);
                switch (character) {
                    case 'X':
                        this.walls.add(new Wall(this.levelNumber, col * App.TILE_SIZE, row * App.TILE_SIZE, 0));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 0));
                        break;
                    case '1':
                        this.walls.add(new Wall(this.levelNumber, col * App.TILE_SIZE, row * App.TILE_SIZE, 1));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 1));
                        break;
                    case '2':
                        this.walls.add(new Wall(this.levelNumber, col * App.TILE_SIZE, row * App.TILE_SIZE, 2));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 2));
                        break;
                    case '3':
                        this.walls.add(new Wall(this.levelNumber, col * App.TILE_SIZE, row * App.TILE_SIZE, 3));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 3));
                        break;
                    case '4':
                        this.walls.add(new Wall(this.levelNumber, col * App.TILE_SIZE, row * App.TILE_SIZE, 4));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 4));
                        break;
                    case 'S':
                        this.spawners.add(new Spawner(col, row));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 0));
                        break;
                    case 'H':
                        this.holes.add(new Hole(app, col * App.TILE_SIZE, row * App.TILE_SIZE, line.charAt(i + 1) - '0', config));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 0));
                        this.tiles.add(new Tile(this.levelNumber, col + 1, row, 0));
                        this.tiles.add(new Tile(this.levelNumber, col, row + 1, 0));
                        this.tiles.add(new Tile(this.levelNumber, col + 1, row + 1, 0));
                        col++;
                        break;
                    case 'B':
                        this.balls.add(new Ball(app, line.charAt(i + 1) - '0'));
                        this.balls.get(this.balls.size() - 1).spawn(new Spawner(col, row));
                        this.tiles.add(new Tile(this.levelNumber, col, row, 0));
                        col++;
                        break;
                    default:
                        this.tiles.add(new Tile(this.levelNumber, col, row, 0));
                        break;
                }
                col++;
            }
            row++;
            col = 0;
        }
    }

    public List<Ball> getBalls() {
        return this.balls;
    }

    public List<Wall> getWalls() {
        return this.walls;
    }

    public List<Hole> getHoles() {
        return this.holes;
    }

    public List<Spawner> getSpawners() {
        return this.spawners;
    }

    public float getSpawnInterval() {
        return this.config.getSpawnInterval();
    }

    public float getLevelTime() {
        return this.config.getLevelTime();
    }

    public int getMaxLevels() {
        return this.maxLevels;
    }

    public List<Tile> getTiles() {
        return this.tiles;
    }
}
package inkball;

import processing.core.PApplet;

public class Hole {
    private float x;
    private float y;
    private int color;
    private int scoreValue;
    private float radius;
    private boolean isAttracting;

    private App app;

    public Hole(App app, float x, float y, int color, Config config) {
        this.app = app;
        this.x = x;
        this.y = y;
        this.color = color;
        this.scoreValue = (int) config.getScoreIncreaseFromHoleCapture(); // Cast to int
        this.radius = App.TILE_SIZE * 2 / 2f;
        this.isAttracting = false;
    }

    public void update() {
        this.isAttracting = false;
    }

    public boolean isAttractingBall(Ball ball) {
        float distance = PApplet.dist(ball.getX(), ball.getY(), this.x + App.TILE_SIZE, this.y + App.TILE_SIZE);
        if (distance < this.radius) {
            this.isAttracting = true;
            return true;
        }
        return false;
    }

    public void attractBall(Ball ball) {
        float dx = this.x + App.TILE_SIZE - ball.getX();
        float dy = this.y + App.TILE_SIZE - ball.getY();
        float attractionForce = 0.005f;

        ball.setDx(ball.getDx() + dx * attractionForce); // Use setter methods
        ball.setDy(ball.getDy() + dy * attractionForce);
    }

    public boolean isBallCaptured(Ball ball) {
        float distance = PApplet.dist(ball.getX(), ball.getY(), this.x + App.TILE_SIZE, this.y + App.TILE_SIZE);
        return distance < app.getBallRadius(); // Access BALL_RADIUS via getter
    }

    public boolean isMatchingColor(Ball ball) {
        return this.color == ball.getColor();
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public int getColor() {
        return this.color;
    }

    public int getScoreValue() {
        return this.scoreValue;
    }
}
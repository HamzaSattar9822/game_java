package inkball;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Config {
    private String configFilePath;
    private JsonObject jsonObject;
    private Map<Integer, String> layouts;
    private int maxLevels;

    public Config(String configFilePath) {
        this.configFilePath = configFilePath;
        this.layouts = new HashMap<>();
        loadConfig();
    }

    private void loadConfig() {
        try (FileReader reader = new FileReader(this.configFilePath)) {
            JsonParser parser = new JsonParser();
            JsonElement root = parser.parse(reader);
            this.jsonObject = root.getAsJsonObject();

            // Get the number of levels from the "levels" array
            this.maxLevels = this.jsonObject.get("levels").getAsJsonArray().size();

            // Store the layout file path for each level
            for (int i = 1; i <= this.maxLevels; i++) {
                this.layouts.put(i, this.jsonObject.get("levels").getAsJsonArray().get(i - 1)
                        .getAsJsonObject().get("layout").getAsString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Getter for the level layout file path
    public String getLayout(int levelNumber) {
        return this.layouts.get(levelNumber);
    }

    // Getter for the spawn interval
    public float getSpawnInterval() {
        return this.jsonObject.get("spawn_interval").getAsFloat();
    }

    // Getter for the level time
    public float getLevelTime() {
        return this.jsonObject.get("time").getAsFloat();
    }

    // Getter for the score increase from hole capture
    public float getScoreIncreaseFromHoleCapture() {
        return this.jsonObject.get("score_increase_from_hole_capture").getAsFloat();
    }

    // Getter for the score increase modifier
    public float getScoreIncreaseFromHoleCaptureModifier() {
        return this.jsonObject.get("score_increase_from_hole_capture_modifier").getAsFloat();
    }

    // Getter for the score decrease from wrong hole
    public float getScoreDecreaseFromWrongHole() {
        return this.jsonObject.get("score_decrease_from_wrong_hole").getAsFloat();
    }

    // Getter for the score decrease modifier
    public float getScoreDecreaseFromWrongHoleModifier() {
        return this.jsonObject.get("score_decrease_from_wrong_hole_modifier").getAsFloat();
    }

    // Getter for the maximum number of levels
    public int getMaxLevels() {
        return this.maxLevels;
    }
}
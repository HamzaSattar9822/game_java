package inkball;

public class Tile {
    private int levelNumber;
    private float x;
    private float y;
    private int color;

    public Tile(int levelNumber, float x, float y, int color) {
        this.levelNumber = levelNumber;
        this.x = x;
        this.y = y;
        this.color = color;
    }

    public float getX() {
        return this.x * App.TILE_SIZE;
    }

    public float getY() {
        return this.y * App.TILE_SIZE;
    }

    public int getColor() {
        return this.color;
    }
}
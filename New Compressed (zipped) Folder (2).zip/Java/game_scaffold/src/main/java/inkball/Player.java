package inkball; // Make sure this line is at the top of Player.java

import java.util.ArrayList;
import java.util.List;

public class Player {
    private App app;
    private List<PlayerLine> lines;
    private boolean isDrawing;
    private float startX;
    private float startY;

    public Player(App app) {
        this.app = app;
        this.lines = new ArrayList<>();
        this.isDrawing = false;
    }

    public void update() {
        // No update logic for the player itself.
    }

    public void startLine(float x, float y) {
        this.isDrawing = true;
        this.startX = x;
        this.startY = y;
    }

    public void extendLine(float x, float y) {
        if (this.isDrawing) {
            this.lines.add(new PlayerLine(app, this.startX, this.startY, x, y));
        }
    }

    public void endLine() {
        this.isDrawing = false;
    }

    public void removeLine(float x, float y) {
        for (int i = this.lines.size() - 1; i >= 0; i--) {
            PlayerLine line = this.lines.get(i);
            if (line.isPointOnLine(x, y)) {
                this.lines.remove(i);
                return;
            }
        }
    }
}
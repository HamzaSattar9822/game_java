package inkball;

import processing.core.PApplet;

public class PlayerLine {
    private float x1;
    private float y1;
    private float x2;
    private float y2;
    private boolean isRemoved;
    private App app;

    public PlayerLine(App app, float x1, float y1, float x2, float y2) {
        this.app = app;
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.isRemoved = false;
    }

    public void update() {
        if (this.isRemoved) {
            return;
        }
        // No update logic for the line itself.
    }

    public void draw() {
        if (this.isRemoved) {
            return;
        }
        this.app.stroke(0);
        this.app.strokeWeight(10);
        this.app.line(this.x1, this.y1, this.x2, this.y2);
    }

    public void remove() {
        this.isRemoved = true;
    }

    // Check if point lies on the line segment
    private boolean isPointOnLineSegment(float px, float py, float lx1, float ly1, float lx2, float ly2) {
        boolean withinX = (px >= lx1 && px <= lx2) || (px >= lx2 && px <= lx1);
        boolean withinY = (py >= ly1 && py <= ly2) || (py >= ly2 && py <= ly1);
        return withinX && withinY;
    }

    // Calculate distance from point to line segment
    private float lineDist(float px, float py, float x1, float y1, float x2, float y2) {
        float A = px - x1;
        float B = py - y1;
        float C = x2 - x1;
        float D = y2 - y1;

        float dot = A * C + B * D;
        float len_sq = C * C + D * D;
        float param = -1;
        if (len_sq != 0) {
            param = dot / len_sq;
        }

        float xx, yy;
        if (param < 0) {
            xx = x1;
            yy = y1;
        } else if (param > 1) {
            xx = x2;
            yy = y2;
        } else {
            xx = x1 + param * C;
            yy = y1 + param * D;
        }

        float dx = px - xx;
        float dy = py - yy;
        return PApplet.dist(px, py, xx, yy);
    }

    public boolean isCollidingWith(Ball ball) {
        // Using the corrected line-point distance formula
        float distToLine = lineDist(ball.getX(), ball.getY(), this.x1, this.y1, this.x2, this.y2);

        // Check for collision and ensure the collision point is within the line segment
        if (distToLine <= ball.getWidth() / 2
                && isPointOnLineSegment(ball.getX(), ball.getY(), this.x1, this.y1, this.x2, this.y2)) {
            return true;
        }
        return false;
    }

    public float[] getNormal() {
        float dx = this.x2 - this.x1;
        float dy = this.y2 - this.y1;
        float[] normal = {-dy, dx};
        float magnitude = PApplet.sqrt(normal[0] * normal[0] + normal[1] * normal[1]);
        normal[0] /= magnitude;
        normal[1] /= magnitude;
        return normal;
    }

    public boolean isPointOnLine(float x, float y) {
        // Calculate the distance from the point to each end of the line
        float distance1 = PApplet.dist(x, y, this.x1, this.y1);
        float distance2 = PApplet.dist(x, y, this.x2, this.y2);

        // Calculate the length of the line
        float lineLength = PApplet.dist(this.x1, this.y1, this.x2, this.y2);

        // Check if the sum of the distances to the endpoints is approximately equal to the line length
        return Math.abs(distance1 + distance2 - lineLength) < 10; // 10 is a tolerance value
    }
}
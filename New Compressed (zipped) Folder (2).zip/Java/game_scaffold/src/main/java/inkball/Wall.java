package inkball;

import processing.core.PApplet;

public class Wall {
    private int levelNumber;
    private float x;
    private float y;
    private int color;

    public Wall(int levelNumber, float x, float y, int color) {
        this.levelNumber = levelNumber;
        this.x = x;
        this.y = y;
        this.color = color;
    }

    public boolean isCollidingWith(Ball ball) {
        // Calculate the center of the ball
        float ballCenterX = ball.getX() + ball.getWidth() / 2f;
        float ballCenterY = ball.getY() + ball.getHeight() / 2f;

        // Calculate the closest point on the wall to the ball's center
        float closestX = PApplet.constrain(ballCenterX, this.x, this.x + App.TILE_SIZE);
        float closestY = PApplet.constrain(ballCenterY, this.y, this.y + App.TILE_SIZE);

        // Calculate the distance between the closest point and the ball's center
        float distance = PApplet.dist(ballCenterX, ballCenterY, closestX, closestY);

        // Check for collision
        return distance <= ball.getWidth() / 2f;
    }

    // Pass the Ball object to getNormal()
    public float[] getNormal(Ball ball) {
        // Determine which side of the wall the ball hit
        float ballCenterX = ball.getX() + ball.getWidth() / 2f;
        float ballCenterY = ball.getY() + ball.getHeight() / 2f;

        if (ballCenterX < this.x) {
            return new float[]{-1, 0}; // Left side
        } else if (ballCenterX > this.x + App.TILE_SIZE) {
            return new float[]{1, 0}; // Right side
        } else if (ballCenterY < this.y) {
            return new float[]{0, -1}; // Top side
        } else {
            return new float[]{0, 1}; // Bottom side
        }
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public int getColor() {
        return this.color;
    }
}